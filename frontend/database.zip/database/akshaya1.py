# Graph representation (Adjacency List)
graph = {
    '5': ['3', '7'],
    '3': ['2', '4'],
    '7': ['8'],
    '2': [],
    '4': ['8'],
    '8': []
}

# BFS function
def bfs(visited, graph, node):
    queue = []  # Initialize queue

    visited.append(node)
    queue.append(node)

    while queue:
        m = queue.pop(0)
        print(m, end=" ")

        for neighbour in graph[m]:
            if neighbour not in visited:
                visited.append(neighbour)
                queue.append(neighbour)

# Driver code
visited = []
print("Following is the Breadth-First Search:")
bfs(visited, graph, '5')
